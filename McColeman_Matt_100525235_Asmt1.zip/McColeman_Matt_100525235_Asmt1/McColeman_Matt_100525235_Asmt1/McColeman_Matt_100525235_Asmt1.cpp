// Matt_McColeman_asgn01.cpp : Defines the entry point for the console application.
/*
Author: Matt McColeman
Date: October 22, 2014
student id: 100525235
Assignment:
Part 1: create a projectile motion simulation
Part 2: create a reverse complemnt sequence of nucleotides
Part 3: approximate Pi using Gregory Liebniz series
Part 4: create two vectors and find the common elements within them
*/

//calling libraries
#include "stdafx.h"
#include <iostream>
#include <vector>
#include <math.h>
#include <iomanip>

//enables standard
using namespace std;

//parameter for simulateProjectile is timing
void simulateProjectile(double timing)
{
	//initializing variables
	double initial_velocity;
	double gravity;
	double final_velocity;
	double time;
	double peakHeight;
	double time_of_impact;

	//initializing variable values
	initial_velocity = 50;
	gravity = -9.8;
	peakHeight = 0;
	time = 0;
	time_of_impact = 0;
	//equation to find initial final_velocity
	final_velocity = initial_velocity + gravity*time;

	//while loop to determine the time at which the projectile reaches max height
	while (final_velocity > 0){
		final_velocity = initial_velocity + gravity*time;
		time = +time + timing;
	}

	//equation to find peak height using the value determined in the while loop for time
	peakHeight = initial_velocity*time + 0.5*gravity*(time*time);
	//equation to find time of impact since time of ipact is twice the time it takes to reach max height
	time_of_impact = time * 2;

	//print statement to output determined values such as time of impact
	cout << "The time of impact of a projectile with a deltaT of " << timing << " shot directly up with an initial velocity of " << initial_velocity << " m/s is " << time_of_impact << " seconds after." << endl;
}

void reverseComplement(){
	//initializing vectors
	vector<string> complement;
	vector<string> dna;
	//inserting elements into dna vector
	dna.push_back("A");
	dna.push_back("C");
	dna.push_back("T");
	dna.push_back("A");
	dna.push_back("T");
	dna.push_back("T");
	dna.push_back("T");
	dna.push_back("A");
	dna.push_back("G");
	dna.push_back("C");
	dna.push_back("G");
	dna.push_back("A");

	//for loop evaluating the elements in the dna vector and inserting the complement element into the complement vector
	for (int i = 0; i < dna.size(); i++){
		if (dna[i] == "A"){
			complement.push_back("T");
		}
		if (dna[i] == "T"){
			complement.push_back("A");
		}
		if (dna[i] == "C"){
			complement.push_back("G");
		}
		if (dna[i] == "G"){
			complement.push_back("C");
		}
	}

	//print statement
	cout << "The reverse complement of the DNA sequence is |";

	//for loop evaluating the elements in the complement vector and printing out the reverse complement sequence of the original dna vector
	for (int i = complement.size() - 1; i >= 0; i--){
		if (complement[i] == "A"){
			cout << "A" << "|";
		}
		if (complement[i] == "T"){
			cout << "T" << "|";
		}
		if (complement[i] == "C"){
			cout << "C" << "|";
		}
		if (complement[i] == "G"){
			cout << "G" << "|";
		}

	}
}

void gregoryLiebniz(){
	//initializing variables
	double pi_estimate;
	int numiterations;
	int i;
	//initializing variable values
	pi_estimate = 0;
	numiterations = 10e5;

	//for loop excecuting the Gregory Liebniz series to a certain amount of iterations
	for (i = 0; i < numiterations; i++) {
		pi_estimate += (4 * pow(-1, i)) / ((2 * i) + 1);
	}
	//print statement outputting the approximation of Pi
	cout << "Using " << numiterations << " in the gregory Liebeniz series we approximate Pi to be " << setiosflags(ios::fixed) << setprecision(6) << pi_estimate << endl;
}

void intersect(){
	//initialize vectors
	vector<int> first;
	vector<int> second;
	vector<int> common;
	//initialize variables
	int i;
	int j;
	//insert element values into vectors
	first.push_back(1);
	first.push_back(2);
	first.push_back(3);
	first.push_back(4);
	first.push_back(5);

	second.push_back(5);
	second.push_back(1);
	second.push_back(7);
	second.push_back(8);
	second.push_back(9);

	//nested for loop to compare all elements in the second vector to each element in the first vector
	//if a common element is found it is inserted into the common vector
	for (i = 0; i < first.size(); i++){
		for (j = 0; j < second.size(); j++){
			if (first[i] == second[j]){
				common.push_back(first[i]);
			}

		}
	}

	//print statement
	cout << "The first vector and the second vector intersect at the common points ";

	//for loop to print all the elements within the common vector
	for (i = 0; i < common.size(); i++){
		cout << common[i] << " & ";
	}

	//print statement
	cout << "that is it.";
}

int _tmain(int argc, _TCHAR* argv[])
{
	//calling each function for each part in the main function
	//Part 1
	cout << "PART 1:" << endl;
	//implementing multiple parameter values for part 1
	simulateProjectile(0.1);
	cout << endl;

	simulateProjectile(0.01);
	cout << endl;

	simulateProjectile(0.001);
	cout << endl;

	simulateProjectile(0.0001);
	cout << endl;

	//Part 2
	cout << "PART 2:" << endl;

	reverseComplement();
	cout << endl << endl;

	//Part 3
	cout << "PART 3:" << endl;

	gregoryLiebniz();
	cout << endl;

	//Part 4
	cout << "PART 4:" << endl;

	intersect();

	return 0;
}

