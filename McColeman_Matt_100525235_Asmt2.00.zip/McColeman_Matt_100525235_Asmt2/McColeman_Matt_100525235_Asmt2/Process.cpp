#include "stdafx.h"
#include "Process.h"
#include <vector>

//process takes the parameters duration and requiredEndTime
Process::Process(int duration, int requiredEndTime)
{
	//allows the variables to be accessed globaly
	this->duration = duration;
	this->endTime = requiredEndTime;
}

//the following two functions return the related variables to be called elseware
int Process::getRequiredEndTime(){
	return endTime;
};
int Process::getDuration(){
	return duration;
};
//defines function scheduled to take parameters of the vector
void scheduled(vector<Process> scheduled){
};



