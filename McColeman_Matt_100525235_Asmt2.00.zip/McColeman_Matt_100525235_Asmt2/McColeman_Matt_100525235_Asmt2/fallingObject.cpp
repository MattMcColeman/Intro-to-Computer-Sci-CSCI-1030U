//calling libraries
#include "stdafx.h"
#include "fallingObject.h"
#include <iostream>
#include <vector>

using namespace std;

//defining falling Object as a member of the class fallingObject
//establishing paramenters
fallingObject::fallingObject(float mass, float surfaceArea, float bungeeSpringConstant, float unstretchedLength){
	//allowing variables to be used publicly
	this->mass = mass; this->surfaceArea = surfaceArea; this->bungeeSpringConstant = bungeeSpringConstant; this->unstretchedLength = unstretchedLength;
};

//function containing physics calculations and time
//:: connects fallingObject and SimulateTimeStep
void fallingObject::simulateTimeStep(float deltaT){

	//increases time by 0.01 each increment
	elapsedTime += deltaT;

	gravity = 9.81;

	//calculates force due to gravity
	fWeight = mass * gravity;

	//calculates the force once the cord is fully extended
	if (length > unstretchedLength){
		fSpring = -bungeeSpringConstant * (length - unstretchedLength);
	}
	else{
		fSpring = 0;
	}

	//calulates the force of friction
	fFriction = -0.65 * surfaceArea * velocity * abs(velocity);

	//calculates the combined forces
	fTotal = fWeight + fFriction + fSpring;

	//calculates the acceleration
	acceleration = fTotal / mass;

	//calculates the velocity
	velocity += acceleration * deltaT;

	//calculates the distance of the person from the jump point
	length += velocity * deltaT;

	//cout << mass << " " << surfaceArea << " " << bungeeSpringConstant << " " << unstretchedLength << endl;
};

//following three functions return values calculated above so they may be called elseware
float fallingObject::getFallDistance(){
	return length;
};

float fallingObject::getAcceleration(){
	return acceleration;
};

float fallingObject::getVelocity(){
	return velocity;
};