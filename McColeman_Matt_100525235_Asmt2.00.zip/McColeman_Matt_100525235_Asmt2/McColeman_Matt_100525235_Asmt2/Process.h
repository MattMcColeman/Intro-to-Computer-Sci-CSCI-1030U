#pragma once
#include "stdafx.h"
#include <iostream>
#include <vector>

using namespace std;

//create class called Process
class Process
{
	//allows variables to be publicly accessed
public:
	//declare variables
	int duration;
	int startTime;
	int endTime;
	int getMinimumRequiredEndTime(vector<Process> processes);
	int getRequiredEndTime();
	int getStartTime();
	int getDuration();
	//declaring vector
	vector<Process> scheduleProcesses;
	//declaring parameters
	Process(int duration, int requiredEndTime);
	Process(int startTime);
};

