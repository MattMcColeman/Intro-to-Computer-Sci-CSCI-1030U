//calling libraries
#pragma once
#include "stdafx.h"
#include <iostream>
#include <vector>

using namespace std;

//creating a class
class fallingObject{
	//making variables accessable publicly
public:
	//declaring variables
	float gravity = 9.8;
	float FallDistance;
	float velocity = 0;
	float elapsedTime = 0;
	float length = 0;
	float fWeight;
	float fFriction;
	float fSpring;
	float fTotal;
	float acceleration;
	float deltaT;
	float cord;
	float mass;
	float surfaceArea;
	float bungeeSpringConstant;
	float unstretchedLength;
	float getFallDistance();
	float getAcceleration();
	float getVelocity();
	//declaring parameters
	void simulateTimeStep(float deltaT);
	fallingObject(float mass, float surfaceArea, float bungeeSpringConstant, float unstretchedLength);
};

