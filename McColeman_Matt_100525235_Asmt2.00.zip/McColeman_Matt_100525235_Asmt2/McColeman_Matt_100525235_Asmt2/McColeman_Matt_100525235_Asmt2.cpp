// Matt_McColeman_100525235_Asmt02.00.cpp : Defines the entry point for the console application.
/*
Author: Matt McColeman
Student ID: 100525235
Date: 26/11/2014
Title: Assignment 2
Brief Discription:	Part 1-create a bungee jump simulation outputting elapased time, current distances, current velocities and current accelerations
					Part 2-using the greedy algorithm run as many of the given processes as possible
*/
//including libraries
#include "stdafx.h"
#include <vector>
#include <math.h>
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include "fallingObject.h"
#include "Process.h"

//standard namespace
using namespace std;

//primary excecution function for Bungee Jump Simulation with ofstream con
void simulateBungeeJump(string outFilename) {
	//formating out file
	ofstream out(outFilename);
	// arguments in order:
	// mass (70kg)
	// surface area (0.2m^2)
	// spring constant for the bungee cord (21.7)
	// unstretched length of bungee cord (30m)
	//establishing objects paramenters
	fallingObject fallingObject(70.0f, 0.2f, 21.7f, 30.0f);


	//creating vectors of floating type
	vector<float> elapsedTimes;
	vector<float> distances;
	vector<float> velocities;
	vector<float> accelerations;

	// time step zero
	//inserting values into vectors
	elapsedTimes.push_back(0.0f);
	distances.push_back(fallingObject.getFallDistance());
	velocities.push_back(fallingObject.getVelocity());
	accelerations.push_back(fallingObject.getAcceleration());

	//assigning values to variables
	//establishing how many times the code must loop based on deltaT and simulationTime
	float simulationTime = 60; // 60 seconds
	float deltaT = 0.01;       // 0.01 seconds
	int timeSteps = (int)(simulationTime / deltaT);

	//prints initial values to document
	out << elapsedTimes[0] << ", " << distances[0] << ", " << velocities[0] << ", " << 0 << endl;

	//for loop inserting calculated values into vectors
	//for loop outputting vector values into document
	for (unsigned int t = 1; t < timeSteps; t++) {
		fallingObject.simulateTimeStep(deltaT);
		elapsedTimes.push_back(t * deltaT);
		distances.push_back(fallingObject.getFallDistance());
		velocities.push_back(fallingObject.getVelocity());
		accelerations.push_back(fallingObject.getAcceleration());
		out << elapsedTimes[t] << ", " << distances[t] << ", " << velocities[t] << ", " << accelerations[t] << endl;
	}

	// save the data to the disk

	// INSERT YOUR CODE HERE
	//closes out of document
	out.close();
}

//vector function to be called in main after being sorted to out the most processes in the possible time frame
vector<Process> scheduleProcesses(vector<Process> processes){
	//creates vectors
	vector <Process> processingValues;
	vector<int> duration;
	vector<int> endTime;
	//creates variable to determine start time
	int times = 0;

	//takes the duration values from processes and inserts it into its own vector
	//takes the RequiredEndTime values from processes and inserts it into its own vector
	for (int i = 0; i < processes.size(); i++)
	{
		duration.push_back(processes[i].getDuration());
		endTime.push_back(processes[i].getRequiredEndTime());
	}

	//sorts values using a nested for loop
	for (int i = 0; i < duration.size(); i++){
		for (int j = 1; j < duration.size(); j++){
			if (duration[j] <= duration[j - 1]){
				//variable used to assist in manipulating the variable
				int endure;
				//swaps adjacent value
				endure = duration[j - 1];
				duration[j - 1] = duration[j];
				duration[j] = endure;
				//swaps adjacent value
				endure = endTime[j - 1];
				endTime[j - 1] = endTime[j];
				endTime[j] = endure;
			}
		}
	}

	//iterates through endTime vector
	for (int x = 0; x < duration.size(); x++){
		//only prints startTime values that have a less than or equal duration value
		if (times < endTime[x]){
			cout << times << "-" << endTime[x] << endl;
		}
		//determines next startTime value by adding previously run durations plus the current duration value
		times = times + duration[x];
	}

	//cout << duration[3] << " " << endTime[3] << endl;

	return processes;
};




int _tmain(int argc, _TCHAR* argv[])
{
	//creates vector processes
	vector<Process> processes;

	//defining process values for duration and 
	Process p1(5, 11);
	Process p2(5, 5);
	Process p3(7, 15);
	Process p4(6, 19);
	Process p5(8, 9);

	//inserting values into the vector processes
	processes.push_back(p1);
	processes.push_back(p2);
	processes.push_back(p3);
	processes.push_back(p4);
	processes.push_back(p5);

	//calling finction in main and sending data to console
	scheduleProcesses(processes);

	//calling function in main and sending data to document
	simulateBungeeJump("Bungee_Jump.txt");

	return 0;
}

